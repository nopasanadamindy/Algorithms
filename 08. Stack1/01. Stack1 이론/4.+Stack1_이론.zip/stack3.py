s=[]

s.append(1)
s.append(2)
s.append(3)

if s:
    print(s.pop())
if s:
    print(s.pop())
if s:
    print(s.pop())
if s:
    print(s.pop())